package com.controller;

import java.awt.image.ImagingOpException;
import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.front.Command;
import com.model.BoardDAO;
import com.model.BoardDTO;


public class UploadService implements Command{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
	
			String title = request.getParameter("title");
			String writer = request.getParameter("writer");
			String content = request.getParameter("content");
			
			BoardDTO dto = new BoardDTO(title, writer, content);
			BoardDAO dao = new BoardDAO();
			
			int cnt = dao.upload(dto);
			System.out.println(title);
			System.out.println(writer);
			System.out.println(content);
			
			if(cnt > 0) {
				System.out.println("���ε� ����");
			} else {
				System.out.println("���ε� ����");
			}
			
		
		
		return "content.jsp#post-preview";
	}
	
}
