package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class predictionDAO {
	
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	private int cnt = 0;

	private void getConn() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
			String dbid = "hr";
			String dbpw = "hr";

			conn = DriverManager.getConnection(url, dbid, dbpw);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void close() {
		try {
			if(rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
	}
	
	public int[] allPredict(String home, String away, int label_num) {
		
		int[] pre = new int[3]; 
		getConn();
		
		String sql = "select * from prediction where lebel_num = ? and match_num = (select match_num from soc_schedule where match_home = ? and match_away = ?)";
		
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, label_num);
			pst.setString(2, home);
			pst.setString(3, away);
			ResultSet rs = pst.executeQuery();
			
			if (rs.next()) {
				int winPer = rs.getInt(3);
				int drawPer = rs.getInt(4);
				int losePer = rs.getInt(5);
				
				pre[0] = winPer;
				pre[1] = drawPer;
				pre[2] = losePer;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close();
		}
		
		return pre;
		
		
		
	}
	
	public predictionDTO selectOne(int num) {
		
		predictionDTO dto = null;
		getConn();
		
		try {
			String sql = "select * from prediction where gamenum = ?";
			pst = conn.prepareStatement(sql);
			pst.setInt(1, num);
			rs = pst.executeQuery();
			if(rs.next()) {
				 int gamenum = rs.getInt(1);
				 int p1_t1win = (int)(rs.getDouble(2) * 100);
				 int p1_t1lose = (int)(rs.getDouble(3) * 100);
				 int p1_draw = (int)(rs.getDouble(4) * 100);
				 int p2_t1win = (int)(rs.getDouble(5) * 100);
				 int p2_t1lose = (int)(rs.getDouble(6) * 100);
				 int p2_draw = (int)(rs.getDouble(7) * 100);
				 int p3_t1win = (int)(rs.getDouble(8) * 100);
				 int p3_t1lose = (int)(rs.getDouble(9) * 100);
				 int p3_draw = (int)(rs.getDouble(10) * 100);
				 
				 dto = new predictionDTO(gamenum, p1_t1win, p1_t1lose, p1_draw, p2_t1win, p2_t1lose, p2_draw, p3_t1win, p3_t1lose, p3_draw);
				 
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close();
		}
		
		
		
		return dto;
	}
	
	
	
	
}

















