package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class voteDAO {
   private Connection conn = null;
   private PreparedStatement pst = null;
   private ResultSet rs = null;
   private int cnt = 0;

   private void getConn() {

      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
         String dbid = "hr";
         String dbpw = "hr";

         conn = DriverManager.getConnection(url, dbid, dbpw);
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }

   private void close() {
      try {
         if (rs != null) {
            rs.close();
         }
         if (pst != null) {
            pst.close();
         }
         if (conn != null) {
            conn.close();
         }
      } catch (SQLException e2) {
         e2.printStackTrace();
      }
   }

   public int votinglist(voteDTO dto) {

      try {

         getConn();

         String sql = "update votinglist set t1win='?', draw='?' , t1lose='?' where votenum =?";
         pst = conn.prepareStatement(sql);
         pst.setInt(1, dto.getT1win());
         pst.setInt(2, dto.getGamenum());

         cnt = pst.executeUpdate();

      } catch (Exception e) {
         e.printStackTrace();
      } finally {

         close();

      }
      return cnt;
   }

   public int update(voteDTO dto , int votenum) {
      int win = dto.getT1win(); // 1
      int draw = dto.getDraw(); // 2
      int lose = dto.getT1lose(); // 3
      int a =0;
      try {
         String sql = "";
         getConn();

         if (win != 0) {
            sql = "update votinglist set t1win = (select  t1win from votinglist where votenum = 1)+1 where votenum = ?";
            a=1;
         } else if (draw !=0) {
            sql = "update votinglist set draw = (select  draw from votinglist where votenum = 1)+1 where votenum = ?";
            a=0;
         } else if (lose !=0) {
            sql = "update votinglist set t1lose = (select t1lose from votinglist where votenum = 1)+1 where votenum = ?";
            a= -1;
         }
         pst = conn.prepareStatement(sql);
         pst.setInt(1, votenum);

         cnt = pst.executeUpdate();

         if (cnt > 0) {
            System.out.println("����");
         } else {
            System.out.println("����");
         }

      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         close();
      }

      return cnt;
   }

   public ArrayList<voteDTO> select() {
      getConn();
      ArrayList<voteDTO> list = new ArrayList<voteDTO>();
      try {

         String sql = "select game.t1name, game.t2name, votinglist.t1win, votinglist.draw,votinglist.t1lose"
               + "vote.votenum from game, votinglist where game.gamenum=votinglist.gamenum";

         pst = conn.prepareStatement(sql);

         rs = pst.executeQuery();

         while (rs.next()) {
            String t1name = rs.getString(1);
            String t2name = rs.getString(2);
            int t1win = rs.getInt(3);
            int t1lose = rs.getInt(5);
            int draw = rs.getInt(4);
            int votenum = rs.getInt(6);
            voteDTO dto = new voteDTO(votenum, t1win, t1lose, draw, t1name, t2name);
            list.add(dto);
         }

      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         close();
      }

      return list;
   }

  
      public voteDTO select4() {
         getConn();
         voteDTO dto= null;
         try {
            
            String sql = "select * from votinglist where gamenum = (select gamenum from game where t1name = '��õ' and t2name = '���')";
            
            pst = conn.prepareStatement(sql);
            
            rs = pst.executeQuery();
            while (rs.next()) {
               int votenum = rs.getInt(1);
               int gamenum = rs.getInt(2);
               int t1win = rs.getInt(3);
               int t1lose = rs.getInt(5);
               int draw = rs.getInt(4);
               int closed = rs.getInt(6);
               dto = new voteDTO(votenum, gamenum, t1win, t1lose, draw, closed);
            }
            
         } catch (SQLException e) {
            e.printStackTrace();
         } finally {
            close();
         }
         
         return dto;
   }   
}