package com.model;

public class voteDTO {

   private int votenum;
   private int gamenum;
   private int t1win ;
   private int t1lose ;
   private int draw ;
   private int closed ;
   private String team1;
   private String team2;
   private String t1name;
   private String t2name;
   
   
   public voteDTO(int t1win, int t1lose, int draw) {
      this.t1win = t1win;
      this.t1lose = t1lose;
      this.draw = draw;
   }



   public voteDTO(int votenum, int t1win, int t1lose, int draw, String t1name, String t2name) {
      this.votenum = votenum;
      this.t1win = t1win;
      this.t1lose = t1lose;
      this.draw = draw;
      this.t1name = t1name;
      this.t2name = t2name;
   }



   public voteDTO(int votenum, int gamenum, int t1win, int t1lose, int draw, int closed) {
      this.votenum = votenum;
      this.gamenum = gamenum;
      this.t1win = t1win;
      this.t1lose = t1lose;
      this.draw = draw;
      this.closed = closed;
   }

   
   
   public voteDTO(int gamenum, int t1win, int t1lose, int draw, int closed) {
      this.gamenum = gamenum;
      this.t1win = t1win;
      this.t1lose = t1lose;
      this.draw = draw;
      this.closed = closed;
   }

   

   public voteDTO(int votenum, int gamenum, int t1win, int t1lose, int draw, int closed, String team1, String team2) {
      super();
      this.votenum = votenum;
      this.gamenum = gamenum;
      this.t1win = t1win;
      this.t1lose = t1lose;
      this.draw = draw;
      this.closed = closed;
      this.team1 = team1;
      this.team2 = team2;
   }



   public int getVotenum() {
      return votenum;
   }

   public void setVotenum(int votenum) {
      this.votenum = votenum;
   }

   public int getGamenum() {
      return gamenum;
   }

   public void setGamenum(int gamenum) {
      this.gamenum = gamenum;
   }

   public int getT1win() {
      return t1win;
   }

   public void setT1win(int t1win) {
      this.t1win = t1win;
   }

   public int getT1lose() {
      return t1lose;
   }

   public void setT1lose(int t1lose) {
      this.t1lose = t1lose;
   }

   public int getDraw() {
      return draw;
   }

   public void setDraw(int draw) {
      this.draw = draw;
   }

   public int getClosed() {
      return closed;
   }

   public void setClosed(int closed) {
      this.closed = closed;
   }



   public String getTeam1() {
      return team1;
   }



   public void setTeam1(String team1) {
      this.team1 = team1;
   }



   public String getTeam2() {
      return team2;
   }



   public void setTeam2(String team2) {
      this.team2 = team2;
   }


   


   
   
}