package com.model;

public class BoardDTO {

	private int boardnum;
	private String title;
	private String writer;
	private String content;
	private String writedate;

	public BoardDTO(int boardnum, String title, String writer, String content, String writedate) {

		this.boardnum = boardnum;
		this.title = title;
		this.writer = writer;
		this.content = content;
		this.writedate = writedate;
	}

	public BoardDTO(String title, String writer, String content) {

		this.title = title;
		this.writer = writer;
		this.content = content;
	}

	public int getBoardnum() {
		return boardnum;
	}

	public void setBoardnum(int boardnum) {
		this.boardnum = boardnum;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWritedate() {
		return writedate;
	}

	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}

}
