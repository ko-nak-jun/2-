package com.model;

public class predictionDTO {

	private int gamenum;
	private int p1_t1win;
	private int p1_t1lose;
	private int p1_draw;
	private int p2_t1win;
	private int p2_t1lose;
	private int p2_draw;
	private int p3_t1win;
	private int p3_t1lose;
	private int p3_draw;
	
	public predictionDTO(int gamenum, int p1_t1win, int p1_t1lose, int p1_draw, int p2_t1win, int p2_t1lose,
			int p2_draw, int p3_t1win, int p3_t1lose, int p3_draw) {
		this.gamenum = gamenum;
		this.p1_t1win = p1_t1win;
		this.p1_t1lose = p1_t1lose;
		this.p1_draw = p1_draw;
		this.p2_t1win = p2_t1win;
		this.p2_t1lose = p2_t1lose;
		this.p2_draw = p2_draw;
		this.p3_t1win = p3_t1win;
		this.p3_t1lose = p3_t1lose;
		this.p3_draw = p3_draw;
	}
	public int getGamenum() {
		return gamenum;
	}
	public void setGamenum(int gamenum) {
		this.gamenum = gamenum;
	}
	public int getP1_t1win() {
		return p1_t1win;
	}
	public void setP1_t1win(int p1_t1win) {
		this.p1_t1win = p1_t1win;
	}
	public int getP1_t1lose() {
		return p1_t1lose;
	}
	public void setP1_t1lose(int p1_t1lose) {
		this.p1_t1lose = p1_t1lose;
	}
	public int getP1_draw() {
		return p1_draw;
	}
	public void setP1_draw(int p1_draw) {
		this.p1_draw = p1_draw;
	}
	public int getP2_t1win() {
		return p2_t1win;
	}
	public void setP2_t1win(int p2_t1win) {
		this.p2_t1win = p2_t1win;
	}
	public int getP2_t1lose() {
		return p2_t1lose;
	}
	public void setP2_t1lose(int p2_t1lose) {
		this.p2_t1lose = p2_t1lose;
	}
	public int getP2_draw() {
		return p2_draw;
	}
	public void setP2_draw(int p2_draw) {
		this.p2_draw = p2_draw;
	}
	public int getP3_t1win() {
		return p3_t1win;
	}
	public void setP3_t1win(int p3_t1win) {
		this.p3_t1win = p3_t1win;
	}
	public int getP3_t1lose() {
		return p3_t1lose;
	}
	public void setP3_t1lose(int p3_t1lose) {
		this.p3_t1lose = p3_t1lose;
	}
	public int getP3_draw() {
		return p3_draw;
	}
	public void setP3_draw(int p3_draw) {
		this.p3_draw = p3_draw;
	}
	
	
	
	
	

}
