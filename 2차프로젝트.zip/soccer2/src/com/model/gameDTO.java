package com.model;

public class gameDTO {
	private int gamenum;
	private String gamedate;
	private String t1name;
	private String t2name;
	private int t1score;
	private int t2score;
	private int over;

	public gameDTO(int gamenum, String gamedate, String t1name, String t2name, int t1score, int t2score, int over) {

		this.gamenum = gamenum;
		this.gamedate = gamedate;
		this.t1name = t1name;
		this.t2name = t2name;
		this.t1score = t1score;
		this.t2score = t2score;
		this.over = over;
	}

	

	public gameDTO(int gamenum, String gamedate, String t1name, String t2name, int over) {
		super();
		this.gamenum = gamenum;
		this.gamedate = gamedate;
		this.t1name = t1name;
		this.t2name = t2name;
		this.over = over;
	}



	public int getGamenum() {
		return gamenum;
	}

	public void setGamenum(int gamenum) {
		this.gamenum = gamenum;
	}

	public String getGamedate() {
		return gamedate;
	}

	public void setGamedate(String gamedate) {
		this.gamedate = gamedate;
	}

	public String getT1name() {
		return t1name;
	}

	public void setT1name(String t1name) {
		this.t1name = t1name;
	}

	public String getT2name() {
		return t2name;
	}

	public void setT2name(String t2name) {
		this.t2name = t2name;
	}

	public int getT1score() {
		return t1score;
	}

	public void setT1score(int t1score) {
		this.t1score = t1score;
	}

	public int getT2score() {
		return t2score;
	}

	public void setT2score(int t2score) {
		this.t2score = t2score;
	}

	public int getOver() {
		return over;
	}

	public void setOver(int over) {
		this.over = over;
	}

}
