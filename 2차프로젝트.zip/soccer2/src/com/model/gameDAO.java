package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class gameDAO {
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	private int cnt = 0;

	private void getConn() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
			String dbid = "hr";
			String dbpw = "hr";

			conn = DriverManager.getConnection(url, dbid, dbpw);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
	}
	public ArrayList<gameDTO> viewAll() {
		ArrayList<gameDTO> list = new ArrayList<gameDTO>();

		try {

			getConn();

			String sql = "select * from game order by gamenum";
			pst = conn.prepareStatement(sql);

			rs = pst.executeQuery();

			while (rs.next()) {
				int gamenum = rs.getInt(1);
				String gamedate = rs.getString(2);
				String t1name = rs.getString(3);
				String t2name = rs.getString(4);
				int over = rs.getInt(7);

				gameDTO bdto = new gameDTO(gamenum, gamedate, t1name, t2name, over);
				list.add(bdto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			close();

		}
		return list;

	}
	
	public gameDTO selectOne(int num) {
		gameDTO dto = null;
		
		getConn();
		
		String sql = "select * from game where gamenum = ?";
		
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, num);
			rs = pst.executeQuery();
			if(rs.next()) {
				 int gamenum = rs.getInt(1);
				 String gamedate = rs.getString(2);
				 String t1name = rs.getString(3);
				 String t2name = rs.getString(4);
				 int t1score = rs.getInt(5);
				 int t2score = rs.getInt(6);
				 int over = rs.getInt(7);
				 
				 dto = new gameDTO(gamenum, gamedate, t1name, t2name, t1score, t2score, over);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close();
		}
		
		return dto;
	}
	
	
	
	
	
	
	
	
	
}
