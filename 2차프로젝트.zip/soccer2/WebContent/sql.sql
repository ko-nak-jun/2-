
create table users(
id varchar2(100) not null,
pw varchar2(100) not null,
nickname varchar2(100) not null,
name varchar2(100) not null,
email varchar2(100) not null,
constraint pk_users_id primary key (id)
);

drop table users;

CREATE SEQUENCE seq_boardnum
START WITH 1
INCREMENT BY 1;

drop sequence seq_boardnum;

drop table board;

create table board(
boardnum number not null,
title varchar2(100) not null,
writer varchar2(100) not null,
content varchar2(1000) not null,
writedate date default sysdate,
constraint pk_board_boardnum primary key(boardnum)
);

create sequence seq_gamenum
start with 1
increment by 1
maxvalue 9999
;

create table game(
gamenum number not null,
gamedate date not null,
t1name varchar2(100) not null,
t2name varchar2(100) not null,
t1score number,
t2score number,
over number not null,
constraint pk_game_gamenum primary key(gamenum),
constraint ck_game_over check(over = 1 or over = 0 or over = -1 or over = -2)--�Ϸ�:1 ������:0 ����:-1 ���:-2
);
alter session
set nls_date_format = 'YYYY-MON-DD';

select * from game;

create table prediction(
gamenum number not null,
p1_t1win number not null,
p1_t1lose number not null,
p1_draw number not null,
p2_t1win number not null,
p2_t1lose number not null,
p2_draw number not null,
p3_t1win number not null,
p3_t1lose number not null,
p3_draw number not null,
constraint fk_game_prediction foreign key(gamenum) references game(gamenum)
);

select * from votinglist;
select * from vote;

create sequence seq_votenum
start with 1
increment by 1
maxvalue 9999
;

drop table votinglist cascade constraint;

create table votinglist(
votenum number not null,
gamenum number not null,
t1win number default 0,
t1lose number default 0,
draw number default 0,
closed number default 0,
constraint pk_votinglist_votenum primary key(votenum),
constraint fk_game_votinglist foreign key(gamenum) references game(gamenum),
constraint ck_votinglist_closed check(closed = 1 or closed = 0) --�Ϸ�:1 ������:0
);

drop table vote cascade constraint;

create table vote(
votenum number not null,
id varchar2(100) not null,
choice number not null,
constraint pk_vote_votenum_id primary key(votenum,id),
constraint fk_votinglist_vote foreign key(votenum) references votinglist(votenum),
constraint ck_vote_choice check(choice = 1 or choice = 0 or choice = -1) --��1����/ ��:1 ��:0 ��:-1
);

insert into users(id, pw, nickname, name, email) values ('id1', '1234', 'nickname1', 'name1', 'email1@email.com');
insert into users(id, pw, nickname, name, email) values ('id2', '1234', 'nickname2', 'name2', 'email2@email.com');
insert into users(id, pw, nickname, name, email) values ('id3', '1234', 'nickname3', 'name3', 'email3@email.com');
insert into users(id, pw, nickname, name, email) values ('id4', '1234', 'nickname4', 'name4', 'email4@email.com');
insert into users(id, pw, nickname, name, email) values ('id5', '1234', 'nickname5', 'name5', 'email5@email.com');


insert into board(boardnum, title, content, writer) values (seq_boardnum.nextval, '����1', '����1', '�ۼ���1');
insert into board(boardnum, title, content, writer) values (seq_boardnum.nextval, '����2', '����2', '�ۼ���2');
insert into board(boardnum, title, content, writer) values (seq_boardnum.nextval, '����3', '����3', '�ۼ���3');
insert into board(boardnum, title, content, writer) values (seq_boardnum.nextval, '����4', '����4', '�ۼ���4');
insert into board(boardnum, title, content, writer) values (seq_boardnum.nextval, '����5', '����5', '�ۼ���5');

insert into game(gamenum, gamedate, t1name, t2name, t1score, t2score, over) values (seq_gamenum.nextval, '2019-09-15', '���', '���', 0, 1, 1);
insert into game(gamenum, gamedate, t1name, t2name, t1score, t2score, over) values (seq_gamenum.nextval, '2020-09-16', '�뱸', '����', 1, 3, 1);


insert into votinglist(votenum, gamenum, t1win, t1lose, draw, closed) values(seq_votenum.nextval, 132, 350, 420, 33, 1);


insert into vote(votenum, id, choice) values(1,'id1',1);





update votinglist set t1win = (select  t1win from votinglist where votenum = 1)+1 where votenum = 1;


